LevelPony
=========

Lightweight Discord.js level system with rewards, based on Mee6's level system.
